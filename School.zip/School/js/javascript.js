$(document).ready(function(){

    $('#menu').slicknav();



    $('.slider').owlCarousel({
        loop:true,
        margin:10,
        autoplay:true,
        nav:false,
        dost:true,
        autoplayTimeout:5000,
        smartSpeed:3000,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    });
    $('.teachers').owlCarousel({
        loop:true,
        margin:10,
        autoplay:false,
        nav:true,
        dost:false,
        autoplayTimeout:2000,
        smartSpeed:600,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:4
            }
        }
    });
    $('.testimonial').owlCarousel({
        loop:true,
        margin:10,
        autoplay:true,
        nav:false,
        dost:true,
        autoplayTimeout:2000,
        smartSpeed:600,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    });

	
});

$(document).ready(function() {
$('.counter').counterUp({
    delay: 10,
    time: 1000
});

 $('.single-image > a').magnificPopup({type:'image'});
});
